module count(
    input clk,          // 50MHz
    input rst_n,        // 复位
    input [1:0] sw,     // 速度选择
    output reg [26:0] data,  // (0-99999999)
    output reg [7:0] point,  // 小数点
    output reg en,           // 使能
    output reg sign          // 符号位
);

parameter MAX_NUM = 23'd5000_000;  // 10Hz

reg [25:0] cnt;
reg flag;

// 速度控制分频器
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt <= 0;
        flag <= 0;
    end
    else begin
        case(sw)
        2'b00: cnt <= (cnt < MAX_NUM-1) ? cnt+1 : 0;
        2'b01: cnt <= (cnt < (MAX_NUM-1)/4) ? cnt+1 : 0;
        2'b10: cnt <= (cnt < (MAX_NUM-1)/8) ? cnt+1 : 0;
        2'b11: cnt <= (cnt < (MAX_NUM-1)/4096) ? cnt+1 : 0;
        endcase
        flag <= (cnt == 0) && !(!rst_n); //在保证rst_n为1（不复位）的情况下，cnt每回到一次0（计数一个周期），就给flag输出一次脉冲
    end
end

// 8位十进制计数器
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        data <= 0;
        point <= 0;
        en <= 0;
        sign <= 0;
    end
    else begin
        point <= 0;
        en <= 1;
        sign <= 0;
        if (flag) data <= (data < 99999999) ? data+1 : 0;
    end
end

endmodule
