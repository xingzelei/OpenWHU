module seg_led_top(
    input      sys_clk,
    input      sys_rst_n,
    input [1:0] sw,
    output [7:0] seg_sel,
    output [7:0] seg_led
);

wire [31:0] data;

count u_count(
    .clk     (sys_clk),
    .rst_n   (sys_rst_n),
    .sw      (sw),
    .data    (data),
    .clk_out (clk_1s)  
);

seg_led u_seg_led(
    .clk     (sys_clk),
    .rst_n   (sys_rst_n),   
    .clk_1s  (clk_1s),  
    .seg_sel (seg_sel),
    .seg_led (seg_led)
);

endmodule
