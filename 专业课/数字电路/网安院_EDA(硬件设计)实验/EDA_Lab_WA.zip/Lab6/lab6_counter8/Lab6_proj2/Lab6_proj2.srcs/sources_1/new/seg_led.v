module seg_led(
    input        clk,          // 50MHz系统时钟
    input        rst_n,        // 低电平复位
    input        clk_1s,       // 分频时钟
    output reg [7:0] seg_sel,  // 位选信号（低有效）
    output reg [7:0] seg_led   // 段选信号（共阳极）
);


reg [5:0] sec, min;
reg [4:0] hour;
always @(posedge clk_1s or negedge rst_n) begin
    if (!rst_n) begin
        sec  <= 0;
        min  <= 0;
        hour <= 0;
    end else begin
        if (sec < 59)
            sec <= sec + 1;
        else begin
            sec <= 0;
            if (min < 59)
                min <= min + 1;
            else begin
                min <= 0;
                if (hour < 23)
                    hour <= hour + 1;
                else
                    hour <= 0;
            end
        end
    end
end

// BCD解码
wire [3:0] hour_ten = hour / 10;
wire [3:0] hour_one = hour % 10;
wire [3:0] min_ten  = min / 10;
wire [3:0] min_one  = min % 10;
wire [3:0] sec_ten  = sec / 10;
wire [3:0] sec_one  = sec % 10;

// 扫描控制（1ms/位）
reg [2:0]  scan_cnt;
reg [12:0] scan_timer;  

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        scan_timer <= 0;
        scan_cnt <= 0;
    end else if (scan_timer >= 13'd5000 - 1) begin  
        scan_timer <= 0;
        scan_cnt <= (scan_cnt < 3'd5) ? scan_cnt + 1 : 0;
    end else begin
        scan_timer <= scan_timer + 1;
    end
end


reg [3:0] num_disp;
reg       dot_disp;

always @(*) begin
    case (scan_cnt)
        3'd0: begin 
            seg_sel  = 8'b11111110;  // 第0位（秒个位）
            num_disp = sec_one;
            dot_disp = 1'b0;        // 小数点关闭
        end
        3'd1: begin 
            seg_sel  = 8'b11111101;  // 第1位（秒十位）
            num_disp = sec_ten;
            dot_disp = 1'b1;        // 分秒之间小数点
        end
        3'd2: begin 
            seg_sel  = 8'b11111011;  // 第2位（分个位）
            num_disp = min_one;
            dot_disp = 1'b0;
        end
        3'd3: begin 
            seg_sel  = 8'b11110111;  // 第3位（分十位）
            num_disp = min_ten;
            dot_disp = 1'b1;        // 时分小数点
        end
        3'd4: begin 
            seg_sel  = 8'b11101111;  // 第4位（时个位）
            num_disp = hour_one;
            dot_disp = 1'b0;
        end
        3'd5: begin 
            seg_sel  = 8'b11011111;  // 第5位（时十位）
            num_disp = hour_ten;
            dot_disp = 1'b0;
        end
        default: begin 
            seg_sel  = 8'b11111111;  // 全部关闭
            num_disp = 4'd0;
            dot_disp = 1'b1;
        end
    endcase
end

// 段选译码（共阳极）
always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        seg_led <= 8'hFF;  
    end else begin
        case (num_disp)
            4'd0: seg_led <= {dot_disp, 7'b1000000}; // 0
            4'd1: seg_led <= {dot_disp, 7'b1111001}; // 1
            4'd2: seg_led <= {dot_disp, 7'b0100100}; // 2
            4'd3: seg_led <= {dot_disp, 7'b0110000}; // 3
            4'd4: seg_led <= {dot_disp, 7'b0011001}; // 4
            4'd5: seg_led <= {dot_disp, 7'b0010010}; // 5
            4'd6: seg_led <= {dot_disp, 7'b0000010}; // 6
            4'd7: seg_led <= {dot_disp, 7'b1111000}; // 7
            4'd8: seg_led <= {dot_disp, 7'b0000000}; // 8
            4'd9: seg_led <= {dot_disp, 7'b0010000}; // 9
            default: seg_led <= {dot_disp, 7'b1111111}; 
        endcase
    end
end

endmodule
