module count(
    input clk,          // 50MHz
    input rst_n,        // 复位
    input [1:0] sw,     // 速度选择
    output reg [26:0] data,  // (0-99999999)
    output reg [7:0] point,  // 小数点
    output reg en,           // 使能
    output reg sign,          // 符号位
    output reg clk_out
);

parameter MAX_NUM = 26'd50_000_000;  // 1秒基准(50MHz时钟)

reg [25:0] cnt;      // 分频计数器
reg [25:0] cnt_max;  // 动态分频系数


always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt_max <= MAX_NUM;
    end else begin
        case(sw)
            2'b00: cnt_max <= MAX_NUM;        // 1s
            2'b01: cnt_max <= MAX_NUM/4;      // 0.25s
            2'b10: cnt_max <= MAX_NUM/8;      // 0.125s
            2'b11: cnt_max <= MAX_NUM/512;    // 约2ms
            default: cnt_max <= MAX_NUM;
        endcase
    end
end

always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        cnt <= 0;
        clk_out <= 0;
    end else begin
        if (cnt >= cnt_max - 1) begin
            cnt <= 0;
            clk_out <= ~clk_out;  
        end else begin
            cnt <= cnt + 1;
        end
    end
end

always @(posedge clk_out or negedge rst_n) begin
    if (!rst_n) begin
        data <= 0;
        point <= 0;
        en <= 1;        
        sign <= 0;      
    end else begin
        if (data < 27'd99_999_999) 
            data <= data + 1;
        else 
            data <= 0;
    end
end
endmodule
