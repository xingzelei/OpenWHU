`timescale 1ns / 1ps

module tb_count8;

reg clk;
reg rst_n;
wire [3:0] oq;
wire [6:0] odisplay;

// 实例化被测模块
count8 uut (
    .clk(clk),
    .rst_n(rst_n),
    .oq(oq),
    .odisplay(odisplay)
);

// 产生100MHz时钟，周期10ns
initial begin
    clk = 0;
    forever #5 clk = ~clk;
end

// 初始化复位信号，复位20ns后释放
initial begin
    rst_n = 0;
    #20;
    rst_n = 1;
end

// 监视输出信号
initial begin
    $monitor("Time=%0t ns, rst_n=%b, oq=%b (%0d), odisplay=%b",
             $time, rst_n, oq, oq, odisplay);
end

// 运行1000us后结束仿真
initial begin
    #1000000;
    $finish;
end

endmodule
