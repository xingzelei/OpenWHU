module JK(
    input clk,
    input rst_n,
    input J,
    input K,
    output reg Q
);
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            Q <= 1'b0;
        else
            Q <= (J & ~Q) | (~K & Q);
    end
endmodule

module display7(
    input [3:0] iData,
    output [6:0] oData
);
    reg [6:0] tData;
    assign oData = tData;

    always @(*) begin
        case(iData)
            4'b0000: tData = 7'b1000000; // 0
            4'b0001: tData = 7'b1111001; // 1
            4'b0010: tData = 7'b0100100; // 2
            4'b0011: tData = 7'b0110000; // 3
            4'b0100: tData = 7'b0011001; // 4
            4'b0101: tData = 7'b0010010; // 5
            4'b0110: tData = 7'b0000010; // 6
            4'b0111: tData = 7'b1111000; // 7
            4'b1000: tData = 7'b0000000; // 8
            4'b1001: tData = 7'b0010000; // 9
            default: tData = 7'b1111111; 
        endcase
    end
endmodule

module Slow(
    input clk,
    input rst_n,
    output reg clk2
);
    reg [25:0] tmp;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n)
            tmp <= 26'b0;
        else if (tmp[25] == 1'b1) begin
            clk2 <= ~clk2;
            tmp <= 26'b0;
        end
        else
            tmp <= tmp + 1;
    end
endmodule

module counter8(
    input clk,
    input rst_n,
    output [3:0] oq,
    output [6:0] odisplay
);
    wire qa, qb, qc, oclk;
    wire ab, y;

    assign ab = qa & qb;
    assign y = ~rst_n;

    Slow slow(.clk(clk), .rst_n(rst_n), .clk2(oclk));

    JK JK_FF0(.clk(oclk), .rst_n(rst_n), .J(1'b1), .K(1'b1), .Q(qa));
    JK JK_FF1(.clk(oclk), .rst_n(rst_n), .J(qa), .K(qa), .Q(qb));
    JK JK_FF2(.clk(oclk), .rst_n(rst_n), .J(ab), .K(ab), .Q(qc));

    assign oq = {1'b0, qc, qb, qa}; 
    display7 disp(.iData(oq[3:0]), .oData(odisplay));

endmodule
