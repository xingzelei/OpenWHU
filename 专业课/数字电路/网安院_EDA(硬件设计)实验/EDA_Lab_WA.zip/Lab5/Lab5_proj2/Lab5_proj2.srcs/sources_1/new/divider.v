`timescale 1ns / 1ps

module divider(
    input I_CLK,
    input rst,
    input [1:0] sw,
    output clk_out
);

    reg clk_out_1 = 1'b0;
    assign clk_out = clk_out_1;

    reg [24:0] cnt;

    always @(posedge I_CLK) begin
        if (rst) 
            cnt <= 0;
        else 
            cnt <= cnt + 1;

        case (sw)
            2'b01: clk_out_1 <= cnt[23];
            2'b10: clk_out_1 <= cnt[22];
            2'b11: clk_out_1 <= cnt[21];
            default: clk_out_1 <= cnt[24];
        endcase
    end

endmodule
