`timescale 1ns / 1ps

module tb_divider;

reg I_CLK;
reg rst;
reg [1:0] sw;
wire clk_out;

// 实例化被测模块
divider uut (
    .I_CLK(I_CLK),
    .rst(rst),
    .sw(sw),
    .clk_out(clk_out)
);

// 产生 100MHz 时钟，周期 10ns
initial begin
    I_CLK = 0;
    forever #5 I_CLK = ~I_CLK;
end

// 初始化复位信号
initial begin
    rst = 1;
    #20;
    rst = 0;
end

// 测试不同的 sw 选择
initial begin
    sw = 2'b00;
    #200_000;  // 200us 观察默认分频
    sw = 2'b01;
    #200_000;  // 200us 观察分频 cnt[23]
    sw = 2'b10;
    #200_000;  // 200us 观察分频 cnt[22]
    sw = 2'b11;
    #200_000;  // 200us 观察分频 cnt[21]

    $stop; // 结束仿真
end

// 监视信号变化
initial begin
    $monitor("Time=%0t ns, rst=%b, sw=%b, clk_out=%b", $time, rst, sw, clk_out);
end

endmodule
