set_property PACKAGE_PIN J15 [get_ports {sw[0]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sw[0]}]
set_property PACKAGE_PIN L16 [get_ports {sw[1]}]
set_property IOSTANDARD LVCMOS33 [get_ports {sw[1]}]

set_property PACKAGE_PIN E3  [get_ports I_CLK]
set_property PACKAGE_PIN J13 [get_ports rst]
set_property IOSTANDARD LVCMOS33 [get_ports I_CLK]
set_property IOSTANDARD LVCMOS33 [get_ports rst]

set_property PACKAGE_PIN H17 [get_ports clk_out]
set_property IOSTANDARD LVCMOS33 [get_ports clk_out]