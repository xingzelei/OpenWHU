`timescale 1ns / 1ps
module FA(
    input iA,       
    input iB,      
    input iC,       
    output oS,      
    output oC       
);
    assign oS = iA ^ iB ^ iC;  
    assign oC = (iA & iB) | (iA & iC) | (iB & iC);  
endmodule
//一位加法器 输入数据iA iB 进位iC 输出结果oS,高位进位oC


module add8(
    input [7:0] iData_a,   
    input [7:0] iData_b,  
    //输入数据a,b
    input iC,
    //级联输入iC               
    output [7:0] oData,
    //最终输出data
    output oData_C      
);
    wire [7:0] carry;  //存储级联输出进位信息的结果
    FA fa0 (
        .iA(iData_a[0]),
        .iB(iData_b[0]),
        .iC(iC),
        .oS(oData[0]),
        .oC(carry[0])
    );//计算第一位，不接收级联输入 输出结果放在oData和carry第一位，

    FA fa1 (
        .iA(iData_a[1]),
        .iB(iData_b[1]),
        .iC(carry[0]),
        .oS(oData[1]),
        .oC(carry[1])
    );//第二位，如上，级联接受carry[0]也就是上一位

    FA fa2 (
        .iA(iData_a[2]),
        .iB(iData_b[2]),
        .iC(carry[1]),
        .oS(oData[2]),
        .oC(carry[2])
    );//后面都是一样的思路

    FA fa3 (
        .iA(iData_a[3]),
        .iB(iData_b[3]),
        .iC(carry[2]),
        .oS(oData[3]),
        .oC(carry[3])
    );

    FA fa4 (
        .iA(iData_a[4]),
        .iB(iData_b[4]),
        .iC(carry[3]),
        .oS(oData[4]),
        .oC(carry[4])
    );

    FA fa5 (
        .iA(iData_a[5]),
        .iB(iData_b[5]),
        .iC(carry[4]),
        .oS(oData[5]),
        .oC(carry[5])
    );

    FA fa6 (
        .iA(iData_a[6]),
        .iB(iData_b[6]),
        .iC(carry[5]),
        .oS(oData[6]),
        .oC(carry[6])
    );

    FA fa7 (
        .iA(iData_a[7]),
        .iB(iData_b[7]),
        .iC(carry[6]),
        .oS(oData[7]),
        .oC(oData_C)//这里是最后一位的加减，注意进位最后呈现到oData的最高位
    );

endmodule

