`timescale 1ns / 1ps

module comp8_tb;
    reg [7:0] iData_a;
    reg [7:0] iData_b;
    wire [2:0] oData;
    
    DataCompare8 uut (
        .iData_a(iData_a),
        .iData_b(iData_b),
        .oData(oData)
    );
    
    integer test_case = 0;
    integer pass_count = 0;
    integer fail_count = 0;
    
    initial begin
        iData_a = 0;
        iData_b = 0;
        
        #10;
        
        test_case = 1;
        iData_a = 8'h12;  
        iData_b = 8'h13; 
        #10;
        verify_result(test_case, oData, 3'b100, "A<B (低位比较)");
        
        test_case = 2;
        iData_a = 8'hF0;  
        iData_b = 8'h0F;  
        #10;
        verify_result(test_case, oData, 3'b001, "A>B (高位比较)");
        
        test_case = 3;
        iData_a = 8'hAA; 
        iData_b = 8'hAA;  
        #10;
        verify_result(test_case, oData, 3'b010, "A==B");
        
        test_case = 4;
        iData_a = 8'h5A;  
        iData_b = 8'h59;  
        #10;
        verify_result(test_case, oData, 3'b001, "A>B (高位相等，低位比较)");
        
        test_case = 5;
        iData_a = 8'hFF;  
        iData_b = 8'h00;  
        #10;
        verify_result(test_case, oData, 3'b001, "A>B (最大值比较)");
        
        #10 $finish;
    end
    
    task verify_result;
        input integer tc;
        input [2:0] actual;
        input [2:0] expected;
        input string desc;
        begin
            if (actual === expected) begin
                $display("[PASS] Test Case %0d (%s): Output=%b", tc, desc, actual);
                pass_count = pass_count + 1;
            end else begin
                $display("[FAIL] Test Case %0d (%s): Expected=%b, Actual=%b", 
                         tc, desc, expected, actual);
                fail_count = fail_count + 1;
            end
        end
    endtask
endmodule
