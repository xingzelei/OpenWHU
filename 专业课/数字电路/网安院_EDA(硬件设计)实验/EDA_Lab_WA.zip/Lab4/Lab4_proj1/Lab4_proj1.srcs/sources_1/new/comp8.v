`timescale 1ns / 1ps

module comp4(
    input [3:0] iData_a,
    input [3:0] iData_b,
    input [2:0] oData, 
    output reg [2:0] compare_result  // 100-A<B，010-A=B，001-A>B
);

always @(*) begin
    if (oData[2]) begin
        compare_result = 3'b100;  
    end else if (oData[0]) begin
        compare_result = 3'b001;  
    end else begin // 010 -- 低位相等，或者000-在比低位
        if (iData_a < iData_b)
            compare_result = 3'b100;  
        else if (iData_a == iData_b)
            compare_result = 3'b010;  
        else
            compare_result = 3'b001;  
    end
end

endmodule


module comp8(
    input [7:0] iData_a,
    input [7:0] iData_b,
    output [2:0] oData
    //oData是最终输出
);

    wire [3:0] iData_a_l;
    wire [3:0] iData_a_h;
    wire [3:0] iData_b_l;
    wire [3:0] iData_b_h;
    wire [2:0] oData_1;

    assign iData_a_l = iData_a[3:0];
    assign iData_a_h = iData_a[7:4];
    assign iData_b_l = iData_b[3:0];
    assign iData_b_h = iData_b[7:4];

    comp4 DataCompare_h(
      .iData_a(iData_a_h),
      .iData_b(iData_b_h),
      // 传入a,b的高位
      .oData(3'b000),  
      //传入000 表明在比高位
      .compare_result(oData_1)
      //接收比较结果 100 010 001
    );

    comp4 DataCompare_l(
      .iData_a(iData_a_l),
      .iData_b(iData_b_l),
      //传入低位
      .oData(oData_1),
      //传入高位比较结果
      .compare_result(oData)
    );
endmodule